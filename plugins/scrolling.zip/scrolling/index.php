<?php 
/*
Plugin Name: Scroling WP
Plugin URI:smartcoderbd.com
Author: Smart Coder
*/
add_action('wp_footer','scrolling_wp');
function scrolling_wp(){
	?>
<button class="scrollingwp">Scrolling</button>
<style>
	.scrollingwp {
		color:white;
		background-color: black;
		border: 0;
		padding:10px;
		right: 20px;
		bottom: 20px;
		z-index: 9999;
		cursor: pointer;
		position: fixed;
	}
</style>
<script>
	jQuery(document).ready(function(){

      jQuery(window).scroll(function(){
      	var top = jQuery(window).scrollTop();
      	if(top < 100) {
      		jQuery(".scrollingwp").hide();
      	}else {
      		jQuery(".scrollingwp").show();
      	}
      });

      jQuery(".scrollingwp").click(function(){
          jQuery("html").animate({"scrollTop": 0},500);

      });

	});
</script>
	<?php
}
?>